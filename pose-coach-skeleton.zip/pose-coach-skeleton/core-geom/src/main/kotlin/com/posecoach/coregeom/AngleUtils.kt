package com.posecoach.coregeom

import kotlin.math.*

object AngleUtils {
    /** Returns angle ABC in degrees, guarding against degenerate vectors. */
    fun angleDeg(ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double): Double {
        val v1x = ax - bx
        val v1y = ay - by
        val v2x = cx - bx
        val v2y = cy - by
        val n1 = hypot(v1x, v1y)
        val n2 = hypot(v2x, v2y)
        if (n1 < 1e-6 || n2 < 1e-6) return Double.NaN
        val dot = (v1x * v2x + v1y * v2y) / (n1 * n2)
        val clamped = dot.coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(clamped))
    }
}
