package com.posecoach.coregeom

/** Minimal One Euro Filter implementation for smoothing landmark coordinates. */
class OneEuroFilter(
    private var minCutoff: Double = 1.0,
    private var beta: Double = 0.0,
    private var dCutoff: Double = 1.0
) {
    private var prevValue: Double? = null
    private var prevDeriv: Double = 0.0
    private var prevTime: Double? = null

    private fun alpha(cutoff: Double, dt: Double): Double {
        val tau = 1.0 / (2 * Math.PI * cutoff)
        return 1.0 / (1.0 + tau / dt)
    }

    fun filter(x: Double, timestampSec: Double): Double {
        val t0 = prevTime
        val dt = if (t0 == null) 1.0 / 60.0 else maxOf(1e-6, timestampSec - t0)
        prevTime = timestampSec

        // derivative of the signal
        val dx = if (prevValue == null) 0.0 else (x - prevValue!!) / dt
        val aD = alpha(dCutoff, dt)
        prevDeriv = aD * dx + (1 - aD) * prevDeriv

        val cutoff = minCutoff + beta * kotlin.math.abs(prevDeriv)
        val a = alpha(cutoff, dt)
        val result = if (prevValue == null) x else a * x + (1 - a) * prevValue!!
        prevValue = result
        return result
    }
}
