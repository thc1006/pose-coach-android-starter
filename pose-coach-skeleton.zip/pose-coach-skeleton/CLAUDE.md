---
title: "Pose Coach Camera — CLAUDE.md"
owners:
  - "Owner Name <owner@example.com>"
project_goal: "在裝置端以 MediaPipe 即時偵測人體姿態並疊骨架；以 Gemini 2.5 Structured Output 回傳 3 條可執行姿勢建議；Live API 僅作語音互動的進階功能。"
non_goals:
  - "不將每幀相機畫面上傳雲端做地標。"
stack:
  - android: "CameraX PreviewView + ImageAnalysis"
  - on_device_ml: "MediaPipe Pose Landmarker (LIVE_STREAM)"
  - ai_text: "Gemini 2.5 (Structured Output)"
  - ai_live: "Gemini Live API (選配)"
conventions:
  language: "Kotlin(Android), Swift(iOS-後期)"
  code_style: "Ktlint/Spotless；命名小駝峰；公用工具放 core-geom/core-pose"
security_privacy:
  - "預設僅在端上處理；僅於使用者同意時上傳地標 JSON；永不上傳原始影像。"
---

# Operating Agreement for Claude Code

## How to work with this repo
1) **TDD**：先寫失敗測試 → 小步實作 → 重構 → 再測。
2) **Task tool first**：每個 Sprint/任務請用 Task 工具建檔於 `.claude/tasks/`。
3) **Respect boundaries**：禁止在相機預覽 Surface 上繪圖；使用 OverlayView 或 CameraX OverlayEffect 疊圖。
4) **Structured Output only**：呼叫 Gemini 時必須帶 `responseSchema`，返回 JSON（見 `/suggestions-api/schema/pose_suggestions.schema.json`）。
5) **Secrets**：讀自 `local.properties` 或環境變數；嚴禁進版本庫。
6) **Privacy**：預設不上傳影像；上傳前需觸發「姿態穩定」gate 並顯示同意提示。

## Definition of Done (DoD)
- 單元測試通過（>80% statement 覆蓋）；關鍵模組均有邊界測試。
- CI 綠：`assemble`、`lint`、`test`。
- README/CHANGELOG 更新，記錄指標：端上推論時間、端到端延遲。
- 隱私檢查表：上傳開關、同意文案、錯誤處理。

## Directory Layout
- `app/`：UI、CameraX、Overlay、DI（此骨架僅佔位）
- `core-geom/`：幾何/角度/平滑工具 + 測試
- `core-pose/`：33 點定義、骨架拓撲、StablePoseGate + 測試
- `suggestions-api/`：Gemini 客戶端封裝、schema、fake client + 測試
- `live-coach/`（opt）：Live API 封裝、狀態機 + 測試
- `docs/`：設計決策、隱私聲明
- `.claude/`：任務檔、代理設定（如有）

## Required APIs & Docs (links mirrored in docs/links.md)
- CameraX Preview & OverlayEffect（developer.android.com）
- MediaPipe Pose Landmarker for Android（developers.google.com/mediapipe）
- Gemini 2.5 Structured Output（ai.google.dev）
- Gemini Live API（ai.google.dev，Preview）

## Test Strategy
- `core-geom`：角度/向量/OneEuroFilter（抖動 vs 延遲）
- `core-pose`：landmark 索引映射、骨架 edge 合法性、StablePoseGate（抖動 vs 穩態）
- `suggestions-api`：schema 驗證、fake client→真 API 對拍

## Coding Checklist (each PR)
- [ ] 單元測試先行並通過
- [ ] 不上傳影像，僅地標 JSON
- [ ] Overlay 對齊（手動檢查清單）
- [ ] 結構化輸出符合 schema
- [ ] README/CHANGELOG 已更新
