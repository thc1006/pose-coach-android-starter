# 文獻與官方文件對照表（核心）
- CameraX Release Notes／OverlayEffect（developer.android.com）
- PreviewView／旋轉方向（developer.android.com）
- MediaPipe Pose Landmarker for Android & General（developers.google.com/mediapipe）
- ML Kit Pose Detection（developers.google.com/ml-kit）
- Gemini 2.5 Structured Output（ai.google.dev）
- Gemini Live API（ai.google.dev）
- One Euro Filter 原始論文與官網（ACM DL / gery.casiez.net）
