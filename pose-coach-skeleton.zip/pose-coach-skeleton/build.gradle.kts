// Placeholder top-level Gradle config. Fill with AGP & Kotlin versions per your environment.
