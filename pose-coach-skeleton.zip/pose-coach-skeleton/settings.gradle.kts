rootProject.name = "pose-coach-camera"
include(":core-geom", ":core-pose", ":suggestions-api", ":app")
